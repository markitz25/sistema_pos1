# sistema_pos/urls.py
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Admin de Django
    path('admin/', admin.site.urls),
    
    # Ruta principal - redirige según autenticación
    path('', lambda request: redirect('/tablero/' if request.user.is_authenticated else '/login/')),
    
    # URLs de autenticación
    path('', include('autenticacion.urls')),
    
    # URLs de las demás apps
    path('tablero/', include('tablero.urls')),
    path('trabajadores/', include('trabajadores.urls')),
    path('inventario/', include('inventario.urls')),
    path('clientes/', include('clientes.urls')),
    path('ventas/', include('ventas.urls')),
    path('reportes/', include('reportes.urls')),
]

# Servir archivos media en desarrollo
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)