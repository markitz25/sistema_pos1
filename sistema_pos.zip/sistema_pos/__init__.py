"""
Inicializa compatibilidad con PyMySQL para usar MySQL sin mysqlclient.
"""
import pymysql

pymysql.install_as_MySQLdb()
